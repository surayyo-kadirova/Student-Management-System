import { Component, OnInit } from '@angular/core';
import { DashboardService } from '../../services/dashboard-service/dashboard.service';
import { Chart } from 'chart.js/auto';
import ChartDataLabels from 'chartjs-plugin-datalabels';

import { StudentService } from '../../services/student-service/student.service';
import { Student } from '../../models/student.model';

Chart.register(ChartDataLabels);

@Component({
  selector: 'app-home',
  standalone: true,
  imports: [],
  templateUrl: './home.component.html',
  styleUrl: './home.component.css'
})
export class HomeComponent  implements OnInit {
  totalStudents = 0;
  enrolledStudents = 0;
  notEnrolledStudents = 0;
  students: Student[] = [];
  courseEnrollmentCounts: { [courseName: string]: number } = {};
  

  constructor(
              private studentService: StudentService
  ) {}

  ngOnInit(): void {
    this.getStudentsWithCourses();
  }

  getStudentsWithCourses(): void {
    this.studentService.getStudents().subscribe(
      (students: Student[]) => {
        this.students = students;
        this.calculateEnrollments();
        this.renderCourseEnrollmentChart();
        this.renderEnrollmentChart();
      },
      (error) => {
        console.error('Error fetching students with courses:', error);
        // You can handle the error here, e.g., showing an error message to the user
      }
    );
  }

  calculateEnrollments(): void {
    this.totalStudents = this.students.length;
    this.enrolledStudents = this.students.filter(student => student.courseName !== "Not enrolled").length;
    this.notEnrolledStudents = this.totalStudents - this.enrolledStudents;
  
    this.students.forEach(student => {
      if (student.courseName && student.courseName !== "Not enrolled") {
        if (!this.courseEnrollmentCounts[student.courseName]) {
          this.courseEnrollmentCounts[student.courseName] = 0;
        }
        this.courseEnrollmentCounts[student.courseName]++;
      }
    });
  }

  renderEnrollmentChart() {
    const ctx = document.getElementById('enrollmentChart') as HTMLCanvasElement;
    new Chart(ctx, {
      type: 'pie',
      data: {
        labels: ['Enrolled', 'Not Enrolled'],
        datasets: [{
          data: [this.enrolledStudents, this.notEnrolledStudents],
          backgroundColor: ['#4BC0C0', '#FF6384'],
          hoverBackgroundColor: ['#4BC0C0', '#FF6384'],
        }]
      },
      options: {
        responsive: true,
        plugins: {
          legend: {
            position: 'top',
          },
          datalabels: {
            formatter: (value, ctx) => {
              let sum = 0;
              const dataArr = ctx.chart.data.datasets[0].data as number[];
              dataArr.forEach((data) => {
                sum += data;
              });
              const percentage = (value * 100 / sum).toFixed(2) + "%";
              return percentage;
            },
            color: '#fff',
            font: {
              size: 13
            }
          }
        }
      }
    });
  }
  renderCourseEnrollmentChart() {
    const ctx = document.getElementById('courseEnrollmentChart') as HTMLCanvasElement;
    new Chart(ctx, {
      type: 'pie',
      data: {
        labels: Object.keys(this.courseEnrollmentCounts),
        datasets: [{
          data: Object.values(this.courseEnrollmentCounts),
          backgroundColor: [
            '#FF6384', '#36A2EB', '#FFCE56', '#4BC0C0', '#9966FF'
          ],
          hoverBackgroundColor: [
            '#FF6384', '#36A2EB', '#FFCE56', '#4BC0C0', '#9966FF'
          ],
       
        }]
      },
      options: {
        responsive: true,
        plugins: {
          legend: {
            position: 'top',
          },
          datalabels: {
            formatter: (value, ctx) => {
              let sum = 0;
              const dataArr = ctx.chart.data.datasets[0].data as number[];
              dataArr.forEach((data) => {
                sum += data;
              });
              const percentage = (value * 100 / sum).toFixed(2) + "%";
              return percentage;
            },
            color: '#fff',
            font: {
              size: 13
            }
          }
        }
      }
    });
  }
  
}