import { Component, NgModule } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { ActivatedRoute, Router } from '@angular/router';
import { StudentService } from '../services/student-service/student.service';


@Component({
  selector: 'app-navbar',
  standalone: true,
  imports: [FormsModule],
  
  templateUrl: './navbar.component.html',
  styleUrl: './navbar.component.css'
})
export class NavbarComponent {
 
  error: string | undefined;
  searchTerm: string = '';

  constructor(private router: Router,private studentService: StudentService,private route: ActivatedRoute){}

  onSearch(): void {
    const trimmedTerm = this.searchTerm.trim();
    if (trimmedTerm) {
      if (!isNaN(+trimmedTerm)) {
        // If the input is a number, navigate to the search by ID route
        this.router.navigate(['/search-student', trimmedTerm]);
      } else {
        // If the input is a string, navigate to the search by name route
        this.router.navigate(['/name'], { queryParams: { name: trimmedTerm } });
      }
    }
  }

  

  }

