import { Injectable } from '@angular/core';
import { HttpClient,HttpHeaders } from '@angular/common/http';
import { AddStudentRequest } from '../../models/add-student-request.model';
import { map, Observable } from 'rxjs';
import { Student } from '../../models/student.model';
import { StudentWithCourseId } from '../../models/students-with-course-id';



@Injectable({
  providedIn: 'root'
})
export class StudentService {

  baseUrl = 'https://localhost:7236/api/CQRStudent';

  constructor(private http: HttpClient) { }

  addStudent(model: AddStudentRequest): Observable<void> {
    return this.http.post<void>(this.baseUrl, model);
  }

  getStudents(): Observable<Student[]> {
    return this.http.get<any>('https://localhost:7236/api/CQRStudent/with-courses');
  }
  getAllStudents(): Observable<StudentWithCourseId[]> {
    return this.http.get<any>(this.baseUrl);
  }

  getStudentById(id: number): Observable<Student> {
    return this.http.get<Student>(`${this.baseUrl}/${id}`);
  }

  getStudentByName(name: string): Observable<Student[]> {
    return this.http.get<Student[]>(`${this.baseUrl}/name?name=${name}`);
  }

  updateStudent(student: Student): Observable<void> {
    return this.http.post<void>(`${this.baseUrl}/${student.id}`, student);
  }

  deleteStudent(id: number): Observable<void> {
    return this.http.delete<void>(`${this.baseUrl}/${id}`);
  }
  registerStudentToCourse(registerData: { Id: number; CourseId: number }): Observable<void> {
    return this.http.post<void>(`${this.baseUrl}/register`, registerData);
  }
  }


