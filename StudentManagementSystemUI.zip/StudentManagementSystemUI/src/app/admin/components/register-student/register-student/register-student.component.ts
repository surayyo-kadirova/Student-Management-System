import { CommonModule } from '@angular/common';
import { Component, NgModule, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, FormsModule, NgForm, ReactiveFormsModule, Validators } from '@angular/forms';
import { StudentService } from '../../services/student-service/student.service';
import { CourseService } from '../../services/course-service/course.service';
import { HttpClientModule } from '@angular/common/http';
import { Student } from '../../models/student.model';
import { Course } from '../../models/course.model';
import { ActivatedRoute } from '@angular/router';
import { Router } from '@angular/router';


@Component({
  selector: 'app-register-student',
  standalone: true,
  imports: [FormsModule,CommonModule,ReactiveFormsModule,HttpClientModule],
  templateUrl: './register-student.component.html',
  styleUrl: './register-student.component.css'
})
export class RegisterStudentComponent implements OnInit {
  registerForm: FormGroup;
  courses: any[] = [];
  students: any[] = [];
  studentName: string | null = null;

  message: string | null = null;
  error: string | null = null;


  constructor(
    private fb: FormBuilder,
    private studentService: StudentService,
    private courseService: CourseService,
    private router: Router
  ) {
    this.registerForm = this.fb.group({
      studentId: ['', [Validators.required, Validators.min(1)]],
      courseId: ['', Validators.required]
    });
  }

  ngOnInit(): void {
    this.loadCourses();

    this.registerForm.get('studentId')?.valueChanges.subscribe(value => {
      this.fetchStudentName(value);
    });
  }
  
  loadCourses(): void {
    this.courseService.getAllCourses().subscribe({
      next: (data) => {
        this.courses = data;
      },
      error: (err) => {
        console.error('Error loading courses:', err);
      }
    });
  }

  fetchStudentName(studentId: number) {
    if (studentId) {
      this.studentService.getStudentById(studentId).subscribe(
        student => {
          this.studentName = `${student.firstName} ${student.lastName}`;
        },
        error => {
          this.studentName = null;
          console.error('Error fetching student name', error);
        }
      );
    } else {
      this.studentName = null;
    }
  }

  onSubmit(): void {
    if (this.registerForm.valid) {
      const registerData = {
        Id: this.registerForm.value.studentId,       // Match with the API expected Id
        CourseId: this.registerForm.value.courseId   // Match with the API expected CourseId
      };
  
      this.studentService.registerStudentToCourse(registerData).subscribe({
        next: (response) => {
          console.log('Update successful', response);
          this.setMessage('Student enrolled successfully!');
          setTimeout(() => this.router.navigate(['/admin/students']), 2000); 
        },
        error: (err) => {
          console.error('Error updating student', err);
          this.setErrorMessage('An error occurred while updating the student.');
        }
      });
    }
  }
  setMessage(msg: string): void {
    this.message = msg;
    this.error = null;
    setTimeout(() => this.message = null, 2000); 
  }

  setErrorMessage(msg: string): void {
    this.error = msg;
    this.message = null;
    setTimeout(() => this.error = null, 2000); // Clear error after 5 seconds
  }
}