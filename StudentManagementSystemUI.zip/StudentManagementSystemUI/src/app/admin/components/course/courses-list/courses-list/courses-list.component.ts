import { Component, OnInit } from '@angular/core';
import { CourseService } from '../../../services/course-service/course.service';
import { Course } from '../../../models/course.model';
import { CommonModule } from '@angular/common';
import { Router, RouterModule } from '@angular/router';
import { HttpClientModule } from '@angular/common/http';

@Component({
  selector: 'app-courses-list',
  standalone: true,
  imports: [CommonModule,RouterModule,HttpClientModule],
  templateUrl: './courses-list.component.html',
  styleUrl: './courses-list.component.css'
})
export class CoursesListComponent implements OnInit {
    courses: Course[] = [];
  
    constructor(private courseService: CourseService,
                private router : Router
    ) {}
  
    ngOnInit(): void {
      this.loadCourses();
    }
  
    loadCourses(): void {
      this.courseService.getAllCourses().subscribe({
        next: (data: Course[]) => {
          this.courses = data;
        },
        error: (err: any) => {
          console.error('Error loading courses', err);
        },
      });
    }
    navigateToAddCourse() {
      this.router.navigate(['/add-course']);
    }
  
    deleteCourse(id: number): void {
      if (confirm('Are you sure you want to delete this course?')) {
          this.courseService.deleteCourse(id).subscribe({
              next: () => {
                  this.loadCourses(); // Refresh the list after deletion
                  alert('Course successfully deleted.');
              },
              error: (err: any) => {
                  console.error('Error deleting course', err);
                  alert('An error occurred while deleting the course. Please try again.');
              }
          });
      }
  }
}
