import { Component } from '@angular/core';
import { Router } from '@angular/router';
import { NgForm } from '@angular/forms';
import { CourseService } from '../../../services/course-service/course.service';
import { Course } from '../../../models/course.model';
import { FormsModule } from '@angular/forms';
import { CommonModule } from '@angular/common';
import { HttpClient, HttpClientModule } from '@angular/common/http';

@Component({
  selector: 'app-add-course',
  standalone: true,
  imports: [FormsModule,CommonModule,HttpClientModule],
  templateUrl: './add-course.component.html',
  styleUrls: ['./add-course.component.css']
})
export class AddCourseComponent {
  course: Course = { id: 0, 
                    courseName: '' };
  message: string | null = null;
  error: string | null = null;

  constructor(private courseService: CourseService, private router: Router) {}

  onSubmit(form: NgForm) {
    if (form.invalid) {
      this.error = 'Please fill out the form correctly.';
      return;
    }

    this.courseService.addCourse(this.course).subscribe({
      next: (response) => {
        this.message = 'Course added successfully!';
        this.error = null;
        form.reset(); // Reset the form after successful submission
        setTimeout(() => this.router.navigate(['/course-list']), 2000); // Redirect to course list after 2 seconds
      },
      error: (err) => {
        this.error = 'An error occurred while adding the course.';
        this.message = null;
        console.error('Error:', err);
      }
    });
  }
}
