import { Component, OnInit } from '@angular/core';
import { StudentService } from '../../services/student-service/student.service';
import { ActivatedRoute, RouterModule, Router } from '@angular/router';
import { HttpClientModule } from '@angular/common/http';
import { CommonModule } from '@angular/common';
import { Student } from '../../models/student.model';
import { FormsModule } from '@angular/forms';

@Component({
  selector: 'app-update-student',
  standalone: true,
  imports: [RouterModule,HttpClientModule,CommonModule,FormsModule],
  templateUrl: './update-student.component.html',
  styleUrl: './update-student.component.css'
})
export class UpdateStudentComponent implements OnInit {
[x: string]: any;
  student: Student = {
    id: 0, firstName: '', lastName: '', dateOfBirth: new Date(), email: '', phoneNumber: '', courseName: ''};
  message: string | null = null;
  error: string | null = null;

  constructor(
    private route: ActivatedRoute,
    private studentService: StudentService,
    private router: Router
  ) { }

  ngOnInit(): void {
    const id = this.route.snapshot.paramMap.get('id');
    if (id) {
      this.studentService.getStudentById(+id).subscribe({
        next: (data) => this.student = data,
        error: (err) => {
          console.error('Error fetching student data', err);
          this.setErrorMessage('Failed to load student details.');
        }
      });
    } else {
      console.error('No student ID provided');
      this.setErrorMessage('Invalid student ID.');
    }
  }

  updateStudent(form: any): void {
    if (form.invalid) {
      this.setErrorMessage('Please fill all the required fields correctly.');
      return;
    }

    this.studentService.updateStudent(this.student).subscribe({
      next: (response) => {
        console.log('Update successful', response);
        this.setMessage('Student updated successfully!');
        setTimeout(() => this.router.navigate(['/admin/students']), 2000); 
      },
      error: (err) => {
        console.error('Error updating student', err);
        this.setErrorMessage('An error occurred while updating the student.');
      }
    });
  }

  setMessage(msg: string): void {
    this.message = msg;
    this.error = null;
    setTimeout(() => this.message = null, 5000); 
  }

  setErrorMessage(msg: string): void {
    this.error = msg;
    this.message = null;
    setTimeout(() => this.error = null, 5000); // Clear error after 5 seconds
  }
}
  







  

