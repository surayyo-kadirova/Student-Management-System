import { CommonModule } from '@angular/common';
import { Component } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { RouterModule } from '@angular/router';
import { Router } from '@angular/router';

@Component({
  selector: 'app-enter-student-id',
  standalone: true,
  imports: [CommonModule,FormsModule,RouterModule],
  template: `
   
   <div class="container mt-5">
      <h1 class="text-center mb-4">Enter Student ID</h1>
      <form (ngSubmit)="onSubmit()" #idForm="ngForm" class="bg-white p-4 shadow-sm rounded">
        <div class="form-group mb-4">
          <label for="studentId" class="form-label">Student ID</label>
          <input
            type="number"
            class="form-control"
            id="studentId"
            [(ngModel)]="studentId"
            name="studentId"
            placeholder="Enter Student ID"
            required
          />
        </div>
        <button type="submit" class="btn btn-primary btn-lg w-100">Proceed to Update</button>
      </form>
    </div>
  `,
  styles: `.container {
    max-width: 500px;
    margin: 0 auto;
    padding: 20px;
    background-color: #ffffff;
    border-radius: 8px;
    box-shadow: 0 4px 12px rgba(0, 0, 0, 0.1);
  }
  h1 {
    font-size: 2rem;
    color: #2c3e50;
    font-weight: 700;
    margin-bottom: 1.5rem;
  }
  .form-label {
    font-weight: 600;
    color: #555;
  }
  .form-control {
    border: 1px solid #ced4da;
    border-radius: 4px;
    padding: 10px;
    font-size: 1rem;
    transition: border-color 0.3s ease, box-shadow 0.3s ease;
  }
  .form-control:focus {
    border-color: #80bdff;
    box-shadow: 0 0 5px rgba(128, 189, 255, 0.5);
  }
  .btn-primary {
  background-color: #2980b9;
  border-color: #2980b9;
  transition: background-color 0.3s ease-in-out, box-shadow 0.3s ease-in-out;
}

.btn-primary:hover {
  background-color: #3498db;
  box-shadow: 0 0 10px rgba(52, 152, 219, 0.5);
    transform: translateY(-2px);
  }
  .w-100 {
    width: 100%;
  }
`,
})
export class EnterStudentIdComponent {

  studentId: number | null = null;

  constructor(private router: Router) {}

  onSubmit(): void {
    if (this.studentId) {
      // Navigate to the update-student page with the entered ID
      this.router.navigate(['/update-student', this.studentId]);
    }
  }
}

