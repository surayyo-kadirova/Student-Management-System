import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { StudentService } from '../../services/student-service/student.service';
import { Student } from '../../models/student.model';
import { CommonModule } from '@angular/common';

@Component({
  selector: 'app-search-student',
  standalone: true,
  imports: [CommonModule],
  templateUrl: './search-student.component.html',
  styleUrl: './search-student.component.css'
})
export class SearchStudentComponent implements OnInit {
  student: Student | null = null;
 
  error: string | null = null;

  constructor(
    private route: ActivatedRoute,
    private studentService: StudentService,
    private router: Router
  ) {}

  ngOnInit(): void {
    this.loadStudentData();
  }

  private loadStudentData(): void {
    const id = this.route.snapshot.paramMap.get('id');
    if (id) {
      this.studentService.getStudentById(+id).subscribe({
        next: (data) => this.student = data,
        error: (err) => {
          console.error('Error fetching student data', err);
          this.error = 'Student not found.';
        }
      });
    } else {
      console.error('No student ID provided');
      this.error = 'Invalid student ID.';
    } 
  }

  navigateToUpdate(id: number): void {
    this.router.navigate(['update-student', id]);
  }

  deleteStudent(id: number): void {
    this.studentService.deleteStudent(id).subscribe({
      next: () => {
        this.router.navigate(['admin/students']); // Redirect to the list page after deletion
        console.log('Student deleted successfully');
      },
      error: (err) => {
        console.error('Error deleting student', err);
        this.error = 'Failed to delete student.';
      }
    });
  }
}
