import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { CommonModule } from '@angular/common';
import { Student } from '../../../models/student.model';
import { StudentService } from '../../../services/student-service/student.service';

@Component({
  selector: 'app-search-student-by-name',
  standalone: true,
  imports: [CommonModule],
  templateUrl: './search-student-by-name.component.html',
  styleUrl: './search-student-by-name.component.css'
})
export class SearchStudentByNameComponent {
  students: Student[] = [];
  searchTerm: string = '';
  error: string | null = null;


  constructor(
    private route: ActivatedRoute,
    private studentService: StudentService,
    private router: Router
  ) {}

  ngOnInit(): void {
    this.loadStudentData();
  }

  private loadStudentData(): void {
    this.route.queryParamMap.subscribe(params => {
      const name = params.get('name');
      console.log(name); // Add this line to log the query parameter
      if (name) {
        this.studentService.getStudentByName(name).subscribe({
          next: (data) => this.students = data,
          error: (err) => {
            console.error('Error fetching student data', err);
            this.error = 'Student not found.';
          }
        });
      } else {
        console.error('No student name provided');
        this.error = 'Invalid student name.';
      }
    });
  }

  navigateToUpdate(id: number): void {
    this.router.navigate(['update-student', id]);
  }

  deleteStudent(id: number): void {
    this.studentService.deleteStudent(id).subscribe({
      next: () => {
        this.router.navigate(['admin/students']); // Redirect to the list page after deletion
        console.log('Student deleted successfully');
      },
      error: (err) => {
        console.error('Error deleting student', err);
        this.error = 'Failed to delete student.';
      }
    });
  }
}
