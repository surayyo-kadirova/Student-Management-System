import { Component } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { Router, RouterModule } from '@angular/router';
import { AddStudentRequest } from '../models/add-student-request.model';
import { HttpClientModule } from '@angular/common/http';
import { CommonModule } from '@angular/common';
import { StudentService } from '../services/student-service/student.service';

@Component({
  selector: 'app-add-student',
  standalone: true,
  imports: [RouterModule, FormsModule, HttpClientModule, CommonModule],
  templateUrl: './add-student.component.html',
  styleUrls: ['./add-student.component.css']
})
export class AddStudentComponent {
  model: AddStudentRequest;
  message: string | null = null;
  error: string | null = null;

  constructor(private studentService: StudentService,
              private router: Router) {
    this.model = {
      firstName: '',
      lastName: '',
      dateOfBirth: new Date(),
      email: '',
      phoneNumber: '',
      courseId: 0
    }; 
  }

  onFormSubmit(form: any) {
    if (form.invalid) {
      this.setErrorMessage('Please fill all the required fields correctly.');
      return;
    }

    this.model.courseId = this.model.courseId === 0 ? null : this.model.courseId;

    this.studentService.addStudent(this.model).subscribe({
      next: (response: any) => {
        this.setMessage('Student registered successfully!');
        this.resetForm(); // Reset form on success
        setTimeout(() => this.router.navigate(['/admin/students']), 2000);
        console.log('Success:', response);
      },
      error: (err) => {
        this.setErrorMessage('An error occurred while registering the student.');
        console.error('Error:', err);
      }
    });
  }

  setMessage(msg: string) {
    this.message = msg;
    this.error = null;
    setTimeout(() => this.message = null, 5000); // Clear message after 5 seconds
  }

  setErrorMessage(msg: string) {
    this.error = msg;
    this.message = null;
    setTimeout(() => this.error = null, 5000); // Clear error after 5 seconds
  }

  resetForm() {
    this.model = {
      firstName: '',
      lastName: '',
      dateOfBirth: new Date(),
      email: '',
      phoneNumber: '',
      courseId: 0
    };
  }
}