
export interface StudentWithCourseId {
    id: number;
    firstName: string;
    lastName: string;
    dateOfBirth: Date;
    email: string;
    phoneNumber: string;
    courseId: number;
    
   
    
}