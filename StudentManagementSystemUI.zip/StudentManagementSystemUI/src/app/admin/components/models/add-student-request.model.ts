export interface AddStudentRequest {
    firstName: string;
    lastName: string;
    dateOfBirth: Date;
    email: string;
    phoneNumber: string;
    courseId: number | null;
    

}
