export interface Course {
    id: number;
    courseName: string;
}