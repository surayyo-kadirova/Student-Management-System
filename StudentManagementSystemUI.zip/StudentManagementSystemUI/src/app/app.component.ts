import { Component } from '@angular/core';
import { RouterOutlet } from '@angular/router';
import { NavbarComponent } from "./admin/components/navbar/navbar.component";
import { FormsModule } from '@angular/forms';
import {  HttpClientModule } from '@angular/common/http';
import { HomeComponent } from "./admin/components/home/home/home.component";
import { AddStudentComponent } from './admin/components/add-student/add-student.component';
import { StudentsListComponent } from './admin/components/student/students-list/students-list.component';
import { NgFor } from '@angular/common';




@Component({
  selector: 'app-root',
  standalone: true,
  imports: [RouterOutlet, NavbarComponent, FormsModule, HttpClientModule, HomeComponent, AddStudentComponent, StudentsListComponent, NgFor],
  templateUrl: './app.component.html',
  styleUrl: './app.component.css'
})
export class AppComponent {
  title = 'SMSUI';
}
