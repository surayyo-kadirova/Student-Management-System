
import { RouterModule, Routes } from '@angular/router';
import { StudentsListComponent } from './admin/components/student/students-list/students-list.component';
import { AddStudentComponent } from './admin/components/add-student/add-student.component';
import { HomeComponent } from './admin/components/home/home/home.component';
import { UpdateStudentComponent } from './admin/components/update-student/update-student/update-student.component';
import { SearchStudentComponent } from './admin/components/search-student/serach-student-by-id/search-student.component';
import { EnterStudentIdComponent } from './admin/components/update-student/enter-student-id/enter-student-id.component';
import { CoursesListComponent } from './admin/components/course/courses-list/courses-list/courses-list.component';
import { AddCourseComponent } from './admin/components/course/add-course/add-course/add-course.component';
import { SearchStudentByNameComponent } from './admin/components/search-student/search-student-by-name/search-student-by-name/search-student-by-name.component';
import { RegisterStudentComponent } from './admin/components/register-student/register-student/register-student.component';

export const routes: Routes = [

  { path: '', component: HomeComponent }, 

    { path: 'admin/students', 
      component: StudentsListComponent},
    
      { path: 'admin/students/add',
        component: AddStudentComponent
      },

        {path: 'update-student/:id',
          component: UpdateStudentComponent
        },

        {path: 'search-student/:id',
          component: SearchStudentComponent
        },

        { path: 'enter-student-id', 
          
          component: EnterStudentIdComponent },

        { path: 'course-list', 
          
            component: CoursesListComponent },

        { path: 'add-course', 
              component: AddCourseComponent },

        {path: 'register-student',
                component: RegisterStudentComponent},
        
        {path: 'name',
                component: SearchStudentByNameComponent}
  


];
export const routing = RouterModule.forRoot(routes);


