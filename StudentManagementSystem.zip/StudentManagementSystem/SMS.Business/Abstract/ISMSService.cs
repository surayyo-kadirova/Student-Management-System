﻿using System;
using SMS.Entities;

namespace SMS.Business.Abstract
{
	public interface ISMSService
    {
		
        Task<List<Student>> GetAllStudents();

        Task<Student> GetStudentById(int Id);

        Task<Student> CreateStudent(Student student);

        Task<Student> UpdateStudent(Student student);

        Task DeleteStudent(int Id);

        
    }
}


