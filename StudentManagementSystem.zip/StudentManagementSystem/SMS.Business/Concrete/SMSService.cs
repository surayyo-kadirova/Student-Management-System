﻿using System;
using SMS.Business.Abstract;
using SMS.DatabaseContext.Abstract;
using SMS.Entities;

namespace SMS.Business.Concrete
{
    public class SMSService : ISMSService
    {
        private ISMSRepository _smsRepository;

        public SMSService(ISMSRepository smsRepository)
        {
            _smsRepository = smsRepository;
        }


        public async Task<Student> CreateStudent(Student student)
        {
            return await _smsRepository.CreateStudent(student);

        }

        public async Task DeleteStudent(int Id)
        {
            if (Id >= 0)
            {
                 await _smsRepository.DeleteStudent(Id);

            }
            else
            {
                throw new Exception("Id can not be less than 1");
            }

        }

        public async Task<List<Student>> GetAllStudents()
        {
            return await _smsRepository.GetAllStudents();
        }

        public async Task<Student> GetStudentById(int Id)
        {
            if (Id >= 0)
            {
                return await _smsRepository.GetStudentById(Id);

            }

            else
            {
                throw new Exception("Id can not be less than 1");
            }
        }

        public async Task<Student> UpdateStudent(Student student)
        {
            return await _smsRepository.UpdateStudent(student);
        }


    }
}


