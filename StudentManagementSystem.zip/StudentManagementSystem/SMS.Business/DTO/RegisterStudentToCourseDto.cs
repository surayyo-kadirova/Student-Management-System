﻿using System;
namespace SMS.Business.DTO
{
    public class RegisterStudentToCourseDto
    {
        public int Id { get; set; }
        public int CourseId { get; set; }
    }
}

