﻿using System;
namespace SMS.Business.StudentWithCourseDTO
{
    public class StudentWithCourseDto
    {
        public StudentWithCourseDto()
        {
            // Initialize non-nullable properties
            FirstName = string.Empty;
            LastName = string.Empty;
            Email = string.Empty;
            PhoneNumber = string.Empty;
            CourseName = string.Empty;
        }
        public int Id { get; set; }

        public string FirstName { get; set; }

        public string LastName { get; set; }

        public DateTime DateOfBirth { get; set; }

        public string Email { get; set; }

        public string PhoneNumber { get; set; }

        public string CourseName { get; set; }
    }
}

