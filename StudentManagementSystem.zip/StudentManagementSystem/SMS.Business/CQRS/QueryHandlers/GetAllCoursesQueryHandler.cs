﻿using System;
using MediatR;
using SMS.Business.CQRS.Queries;
using SMS.DatabaseContext.Abstract;
using SMS.Entities;

namespace SMS.Business.CQRS.QueryHandlers
{
	public class GetAllCoursesQueryHandler: IRequestHandler<GetAllCoursesQuery,List<Course>>
	{
        private readonly ICourseRepository _courseRepository;

        public GetAllCoursesQueryHandler(ICourseRepository courseRepository)
        {
            _courseRepository = courseRepository;
        }

        public async Task<List<Course>> Handle(GetAllCoursesQuery request, CancellationToken cancellationToken)
        {
            return await _courseRepository.GetAllCourses();
        }
    }
}

