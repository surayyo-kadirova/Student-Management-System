﻿using System;
using MediatR;
using SMS.Business.CQRS.Queries;
using SMS.DatabaseContext.Abstract;
using SMS.Entities;

namespace SMS.Business.CQRS.QueryHandlers
{
    public class GetCourseByIdQueryHandler : IRequestHandler<GetCourseByIdQuery, Course>
	{
        private readonly ICourseRepository _courseRepository;

        public GetCourseByIdQueryHandler(ICourseRepository courseRepository)
        {
            _courseRepository = courseRepository;
        }

        public async Task<Course> Handle(GetCourseByIdQuery request, CancellationToken cancellationToken)
        {
            return await _courseRepository.GetCourseById(request.Id);
        }

    }
}

