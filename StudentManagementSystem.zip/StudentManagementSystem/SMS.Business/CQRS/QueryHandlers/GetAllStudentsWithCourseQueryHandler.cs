﻿using System;
using MediatR;
using SMS.Business.CQRS.Queries;
using SMS.Business.StudentWithCourseDTO;
using SMS.DatabaseContext.Abstract;

namespace SMS.Business.CQRS.QueryHandlers
{
    public class GetAllStudentsWithCourseQueryHandler : IRequestHandler<GetAllStudentsWithCourseQuery, List<StudentWithCourseDto>>
    {
        private readonly ISMSRepository _smsRepository;

        public GetAllStudentsWithCourseQueryHandler(ISMSRepository smsRepository)
        {
            _smsRepository = smsRepository;
        }

        public async Task<List<StudentWithCourseDto>> Handle(GetAllStudentsWithCourseQuery request, CancellationToken cancellationToken)
        {
            var students = await _smsRepository.GetAllStudentsWithCourses();

            if (students == null || !students.Any())
            {
                // Handle the case where no students are found
                return new List<StudentWithCourseDto>();
            }

            var studentDtos = students.Select(s => new StudentWithCourseDto
            {
                Id = s.Id,
                FirstName = s.FirstName,
                LastName = s.LastName,
                DateOfBirth = s.DateOfBirth,
                Email = s.Email,
                PhoneNumber = s.PhoneNumber,
                CourseName = s.Course?.CourseName ?? "Not enrolled"
              
            }).OrderBy(s => s.Id).ToList();

            return studentDtos;
        }
    }
}

