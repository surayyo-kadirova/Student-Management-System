﻿using MediatR;
using SMS.Business.CQRS.Queries;
using SMS.Business.StudentWithCourseDTO;
using SMS.DatabaseContext.Abstract;
using SMS.Entities;

namespace SMS.Business.CQRS.QueryHandlers
{
    public class GetStudentByIdQueryHandler : IRequestHandler<GetStudentByIdQuery, StudentWithCourseDto>
    {
        private readonly ISMSRepository _smsRepository;

        public GetStudentByIdQueryHandler(ISMSRepository smsRepository)
        {
            _smsRepository = smsRepository;
        }

        public async Task<StudentWithCourseDto> Handle(GetStudentByIdQuery request, CancellationToken cancellationToken)
        {
            var student = await _smsRepository.GetStudentById(request.Id);

            if (student == null)
            {
                return null; 
            }

            // Map the Student entity to a StudentWithCourseDto
            return new StudentWithCourseDto
            {
                Id = student.Id,
                FirstName = student.FirstName,
                LastName = student.LastName,
                DateOfBirth = student.DateOfBirth,
                Email = student.Email,
                PhoneNumber = student.PhoneNumber,
                CourseName = student.Course?.CourseName ?? "No Course"// Map CourseName from Course entity
            };
        }
    }
}

