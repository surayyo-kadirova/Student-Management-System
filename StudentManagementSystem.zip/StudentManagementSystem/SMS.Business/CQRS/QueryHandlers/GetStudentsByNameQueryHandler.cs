﻿using MediatR;
using SMS.Business.CQRS.Queries;
using SMS.Business.StudentWithCourseDTO;
using SMS.DatabaseContext.Abstract;

namespace SMS.Business.CQRS.QueryHandlers
{
    public class GetStudentsByNameQueryHandler : IRequestHandler<GetStudentsByNameQuery, List<StudentWithCourseDto>>
	{
        private readonly ISMSRepository _repository;

        public GetStudentsByNameQueryHandler(ISMSRepository repository)
        {
            _repository = repository;
        }

        public async Task<List<StudentWithCourseDto>> Handle(GetStudentsByNameQuery request, CancellationToken cancellationToken)
        {
            var students = await _repository.GetStudentsByName(request.Name);
            var studentDtos = students.Select(s => new StudentWithCourseDto
            {
                Id = s.Id,
                FirstName = s.FirstName,
                LastName = s.LastName,
                DateOfBirth = s.DateOfBirth,
                Email = s.Email,
                PhoneNumber = s.PhoneNumber,
                CourseName = s.Course?.CourseName
            }).ToList();

            return studentDtos;
        }
    }
}

