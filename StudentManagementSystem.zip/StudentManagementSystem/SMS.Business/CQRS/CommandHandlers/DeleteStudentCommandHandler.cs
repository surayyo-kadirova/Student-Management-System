﻿using System;
using MediatR;
using SMS.Business.CQRS.Commands;
using SMS.DatabaseContext.Abstract;

namespace SMS.Business.CQRS.CommandHandlers
{

        public class DeleteStudentCommandHandler : IRequestHandler<DeleteStudentCommand>
        {
            private readonly ISMSRepository _repository;

            public DeleteStudentCommandHandler(ISMSRepository repository)
            {
                _repository = repository;
            }

            public async Task<Unit> Handle(DeleteStudentCommand request, CancellationToken cancellationToken)
            {
                await _repository.DeleteStudent(request.Id);
                return Unit.Value;
            }
        }
    
}

