﻿using System;
using MediatR;
using SMS.Business.CQRS.Commands;
using SMS.DatabaseContext.Abstract;
using SMS.DatabaseContext.Concrete;
using SMS.Entities;

namespace SMS.Business.CQRS.CommandHandlers
{
	public class CreateCourseCommandHandler: IRequestHandler<CreateCourseCommand, Course>
	{
		private readonly ICourseRepository _courseRepository;

		public CreateCourseCommandHandler(ICourseRepository courseRepository)
		{
            _courseRepository = courseRepository;
		}

		public async Task<Course>Handle(CreateCourseCommand request, CancellationToken cancellationToken)
		{
			var course = new Course
			{
				CourseName = request.CourseName
			};

			return await _courseRepository.CreateCourse(course);
		    
		}
	}
}

