﻿using MediatR;
using SMS.Business.CQRS.Commands;
using SMS.Business.StudentWithCourseDTO;
using SMS.DatabaseContext.Abstract;
using SMS.Entities;

namespace SMS.Business.CQRS.CommandHandlers
{
    public class UpdateStudentCommandHandler : IRequestHandler<UpdateStudentCommand, StudentWithCourseDto>
    {
        private readonly ISMSRepository _smsRepository;

        public UpdateStudentCommandHandler(ISMSRepository smsRepository)
        {
            _smsRepository = smsRepository;
        }

        public async Task<StudentWithCourseDto> Handle(UpdateStudentCommand request, CancellationToken cancellationToken)
        {
            var student = await _smsRepository.GetStudentById(request.Id);

            if (student == null)
            {
                return null; // Or throw a custom exception if preferred
            }

            // Update student details
            student.FirstName = request.FirstName;
            student.LastName = request.LastName;
            student.DateOfBirth = request.DateOfBirth;
            student.Email = request.Email;
            student.PhoneNumber = request.PhoneNumber;
           
           

            await _smsRepository.UpdateStudent(student);

            // Map entity back to DTO if necessary
            return new StudentWithCourseDto
            {
                Id = student.Id,
                FirstName = student.FirstName,
                LastName = student.LastName,
                DateOfBirth = student.DateOfBirth,
                Email = student.Email,
                PhoneNumber = student.PhoneNumber,
                CourseName = student.Course?.CourseName ?? "No Course"
            };
        }

    }
}


