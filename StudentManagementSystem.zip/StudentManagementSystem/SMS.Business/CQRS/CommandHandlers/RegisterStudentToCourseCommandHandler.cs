﻿using System;
using MediatR;
using SMS.Business.CQRS.Commands;
using SMS.DatabaseContext.Abstract;
using SMS.Entities;

namespace SMS.Business.CQRS.CommandHandlers
{
    public class RegisterStudentToCourseCommandHandler : IRequestHandler<RegisterStudentToCourseCommand, Student>
    {
        private readonly ISMSRepository _smsRepository;
        private readonly ICourseRepository _courseRepository;

        public RegisterStudentToCourseCommandHandler(ISMSRepository smsRepository, ICourseRepository courseRepository)
        {
            _smsRepository = smsRepository;
            _courseRepository = courseRepository;
        }

        public async Task<Student> Handle(RegisterStudentToCourseCommand request, CancellationToken cancellationToken)
        {
            Student student = null;

            if (request.Id.HasValue)
            {
                student = await _smsRepository.GetStudentById(request.Id.Value);
            }
            else
            {
                throw new Exception("Student not found.");
            }

            var course = await _courseRepository.GetCourseById(request.CourseId);

            if (course == null)
            {
                throw new Exception("Course not found.");
            }

            student.CourseId = request.CourseId;
            await _smsRepository.UpdateStudent(student);

            return student;
        }
    }
}

