﻿using System;
using MediatR;
using SMS.Business.CQRS.Commands;
using SMS.DatabaseContext.Abstract;

namespace SMS.Business.CQRS.CommandHandlers
{
	public class DeleteCourseCommandHandler: IRequestHandler<DeleteCourseCommand>
	{
		private readonly ICourseRepository _courseRepository;

		public DeleteCourseCommandHandler(ICourseRepository courseRepository)
		{
			_courseRepository = courseRepository;
		}

		public async Task<Unit>Handle(DeleteCourseCommand request,CancellationToken cancellationToken)
		{
			await _courseRepository.DeleteCourse(request.Id);
			return Unit.Value;
		}
		
	}
}

