﻿using System;
using MediatR;
using SMS.Business.StudentWithCourseDTO;

namespace SMS.Business.CQRS.Queries
{
	public class GetAllStudentsWithCourseQuery: IRequest<List<StudentWithCourseDto>>
	{
		
	}
}

