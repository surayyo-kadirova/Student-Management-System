﻿using MediatR;
using SMS.Business.StudentWithCourseDTO;

namespace SMS.Business.CQRS.Queries
{
	public class GetStudentsByNameQuery: IRequest<List<StudentWithCourseDto>>
	{
        public string Name { get; set; }

        public GetStudentsByNameQuery(string name)
        {
            Name = name;
        }
    }
}

