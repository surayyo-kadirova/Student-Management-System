﻿
using MediatR;
using SMS.Business.StudentWithCourseDTO;
using SMS.Entities;

namespace SMS.Business.CQRS.Queries
{
    public class GetStudentByIdQuery : IRequest<StudentWithCourseDto>
    {
      
            public int Id { get; set; }

            public GetStudentByIdQuery(int id)
            {
                Id = id;
            }
        
    }
}

