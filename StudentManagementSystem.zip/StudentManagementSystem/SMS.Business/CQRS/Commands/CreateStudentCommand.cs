﻿using System;
using MediatR;
using SMS.Entities;

namespace SMS.Business.CQRS.Commands
{
    public class CreateStudentCommand : IRequest<Student>
    {

        public string FirstName { get; set; }

        public string LastName { get; set; }

        public DateTime DateOfBirth { get; set; }

        public string Email { get; set; }

        public string PhoneNumber { get; set; }

        public int? CourseId { get; set;}
    }
}

