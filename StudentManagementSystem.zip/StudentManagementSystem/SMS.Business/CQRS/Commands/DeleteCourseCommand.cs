﻿using System;
using MediatR;

namespace SMS.Business.CQRS.Commands
{
	public class DeleteCourseCommand: IRequest
	{
		public int Id { get; set; }
	}
}

