﻿using System;
using MediatR;
using SMS.Entities;

namespace SMS.Business.CQRS.Commands
{
	public class RegisterStudentToCourseCommand:IRequest<Student>
	{
        public int? Id { get; set; }
        public int CourseId { get; set; }

        public RegisterStudentToCourseCommand(int? id, int courseId)
        {
            Id = id;
            CourseId = courseId;
        }
    }
}

