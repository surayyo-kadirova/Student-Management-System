﻿using System;
using System.Text.Json.Serialization;

namespace SMS.Entities
{
	public class Student
	{

        public Student()
        {
            // Initialize non-nullable properties
            FirstName = string.Empty;
            LastName = string.Empty;
            Email = string.Empty;
            PhoneNumber = string.Empty;
        }

        public int Id { get; set; }

        public string FirstName { get; set; }

        public string LastName { get; set; }

        public DateTime DateOfBirth { get; set; }

        public string Email { get; set; }

        public string PhoneNumber { get; set; }

        public int? CourseId { get; set; }

        [JsonIgnore]
        public Course? Course { get; set; }

      

    }
}


