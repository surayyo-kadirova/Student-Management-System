﻿using System;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace SMS.Entities
{
	public class Course
    {
        public Course()
        {
            CourseName = string.Empty;
        }
        [Key, DatabaseGenerated(DatabaseGeneratedOption.Identity)]
        public int Id { get; set; }

		public string CourseName { get; set; }

        public ICollection<Student>? Students { get; set; }

        public ICollection<Instructor> Instructors { get; set; }


   




    }
}

