﻿using System;
namespace SMS.DatabaseContext.DbDTO
{
	public class CourseEnrollmentDto
	{
        public string CourseName { get; set; }
        public int StudentCount { get; set; }
    }
}

