﻿
using Microsoft.EntityFrameworkCore;
using SMS.DatabaseContext.Abstract;
using SMS.Entities;

namespace SMS.DatabaseContext.Concrete
{

    public class SMSRepository : ISMSRepository
    {
        public SMSDb context = new(); //context yaratmış olduk ve alttakı butun fonksuyonlar görebilir.

        // Get all students
        public async Task<List<Student>> GetAllStudents()
        {
            return await context.Students.ToListAsync();
        }

        // Get all students with course
        public async Task<List<Student>>GetAllStudentsWithCourses()
        {
            try
            {
                return await context.Students
                    .Include(s => s.Course)
                    .ToListAsync();
            }
            catch (Exception ex)
            {
                
                Console.WriteLine($"Error retrieving students with courses: {ex.Message}");
                throw;
            }
        }

        // Get student by Id number
        public async Task<Student> GetStudentById(int Id)
        {
            return await context.Students.Include(s => s.Course).FirstOrDefaultAsync(s => s.Id == Id);
        }

        // Get student by name
        public async Task<List<Student>> GetStudentsByName(string name)
        {
            return await context.Students
                .Include(s => s.Course)
                .Where(s => s.FirstName.Contains(name) || s.LastName.Contains(name))
                .ToListAsync();
        }

        // Add new student to the list
        public async Task<Student> CreateStudent(Student student)
        {
            context.Students.Add(student);
            await context.SaveChangesAsync();
            return student;
        }

        // Update student's information
        public async Task<Student> UpdateStudent(Student student)
        {
            var existingStudent = await context.Students.FirstOrDefaultAsync(s => s.Id == student.Id);
            if (existingStudent != null)
            {
                existingStudent.FirstName = student.FirstName;
                existingStudent.LastName = student.LastName;
                existingStudent.DateOfBirth = student.DateOfBirth;
                existingStudent.Email = student.Email;
                existingStudent.PhoneNumber = student.PhoneNumber;

                await context.SaveChangesAsync();
                return existingStudent;
            }
            else
            {
                return null;
            }
        }

        // Delete student
        public async Task DeleteStudent(int Id)
        {
            var existingStudent = await GetStudentById(Id);
            context.Students.Remove(existingStudent);
            await context.SaveChangesAsync();
        }
 
    }
}
    


      


      