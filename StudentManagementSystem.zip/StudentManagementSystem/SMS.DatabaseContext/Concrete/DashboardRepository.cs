﻿/*using SMS.DatabaseContext.Abstract;
using SMS.DatabaseContext.DbDTO;
using SMS.Entities;
using System.Collections.Generic;
using System.Linq;

namespace SMS.DatabaseContext.Concrete
{
    public class DashboardRepository : IDashboardRepository
    {
       public SMSDb _context = new();
        public int GetTotalStudents()
        {
            return _context.Students.Count();
        }

        public int GetEnrolledStudents()
        {
            return _context.Students.Count(s => s.CourseId != null);
        }

        public List<CourseEnrollmentDto> GetCourseEnrollments()
        {
            return _context.Courses
                .Select(c => new CourseEnrollmentDto
                {
                    CourseName = c.CourseName,
                    StudentCount = c.Students.Count()
                })
                .ToList();
        }


    }
}*/

