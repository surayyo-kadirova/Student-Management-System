﻿
using SMS.Entities;

namespace SMS.DatabaseContext.Abstract
{
	public interface ISMSRepository
	{
      
            Task<List<Student>> GetAllStudents();

            Task<Student> GetStudentById(int Id);

            Task<List<Student>> GetAllStudentsWithCourses();
  
            Task<List<Student>> GetStudentsByName(string name);

            Task<Student> CreateStudent(Student student);

            Task<Student> UpdateStudent(Student student);

            Task DeleteStudent (int Id);   //void olan method olduğu için herhangi bir tip belirtmiyoruz
        
    }
}

