﻿using System;
using SMS.DatabaseContext.DbDTO;

namespace SMS.DatabaseContext.Abstract
{
	public interface IDashboardRepository
	{
        int GetTotalStudents();
        int GetEnrolledStudents();
        List<CourseEnrollmentDto> GetCourseEnrollments();
    }
}

