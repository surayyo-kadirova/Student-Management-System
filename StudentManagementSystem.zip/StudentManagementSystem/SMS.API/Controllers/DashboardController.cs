﻿/*using System;
using Microsoft.AspNetCore.Mvc;
using SMS.DatabaseContext;
using SMS.DatabaseContext.Abstract;

namespace SMS.API.Controllers
{

    [ApiController]
    [Route("api/[controller]")]
    public class DashboardController : ControllerBase
    {
        private readonly IDashboardRepository _dashboardRepository;

        public DashboardController(IDashboardRepository dashboardRepository)
        {
            _dashboardRepository = dashboardRepository;
        }

        [HttpGet("metrics")]
        public IActionResult GetMetrics()
        {
            var totalStudents = _dashboardRepository.GetTotalStudents();
            var enrolledStudents = _dashboardRepository.GetEnrolledStudents();
            var notEnrolledStudents = totalStudents - enrolledStudents;

            return Ok(new
            {
                totalStudents,
                enrolledStudents,
                notEnrolledStudents
            });
        }

        [HttpGet("course-enrollments")]
        public IActionResult GetCourseEnrollments()
        {
            var courseEnrollments = _dashboardRepository.GetCourseEnrollments();
            return Ok(courseEnrollments);
        }
    }
}*/

