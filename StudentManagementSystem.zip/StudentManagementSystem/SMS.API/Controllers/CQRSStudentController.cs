﻿using MediatR;
using Microsoft.AspNetCore.Mvc;
using SMS.Business.CQRS.Commands;
using SMS.Business.CQRS.Queries;
using SMS.Business.StudentWithCourseDTO;
using SMS.Entities;
using System.Threading.Tasks;

namespace SMS.API.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class CQRStudentController : ControllerBase
    {
        private readonly IMediator _mediator;

        public CQRStudentController(IMediator mediator)
        {
            _mediator = mediator;
        }
      
        [HttpGet]
        public async Task<IActionResult> GetAllStudents()
        {
            var students = await _mediator.Send(new GetAllStudentsQuery());
            return Ok(students);
        }

        
        [HttpGet("{id}")]
        public async Task<ActionResult<StudentWithCourseDto>> GetStudentById(int id)
        {
            try
            {
                var student = await _mediator.Send(new GetStudentByIdQuery(id));

                if (student == null)
                {
                    return NotFound($"Student with ID {id} not found.");
                }

                return Ok(student);
            }
            catch (Exception ex)
            {
               
                return StatusCode(500, $"Internal server error: {ex.Message}");
            }
        }


        [HttpGet("with-courses")]
        public async Task<ActionResult<List<StudentWithCourseDto>>>GetAllStudentsWithCourses()
        {
            try
            {
                var students = await _mediator.Send(new GetAllStudentsWithCourseQuery());
                return Ok(students);
            }
            catch (Exception ex)
            {
                return StatusCode(500, $"Internal server error: {ex.Message}");
            }
        }


        [HttpGet("name")]
        public async Task<ActionResult<List<StudentWithCourseDto>>> GetStudentsByName([FromQuery] string name)
        {
            var query = new GetStudentsByNameQuery(name);
            var students = await _mediator.Send(query);
            return Ok(students);
        }


        // Create a new student
        [HttpPost]
        public async Task<IActionResult> CreateStudent([FromBody] CreateStudentCommand command)
        {
            if (!ModelState.IsValid)
            {
                return BadRequest(ModelState);
            }

            try
            {
                var createdStudent = await _mediator.Send(command);
                return CreatedAtAction(nameof(GetStudentById), new { id = createdStudent.Id }, createdStudent); // Returns 201 Created
            }
            catch (Exception ex)
            {
                // Log the exception
                Console.WriteLine($"Error: {ex.Message}");
                return StatusCode(500, "An error occurred while creating the student."); // Returns 500 Internal Server Error for unexpected exceptions
            }
        }


        // Update an existing student
        [HttpPost("{update}")]
        public async Task<IActionResult> UpdateStudent([FromBody] UpdateStudentCommand command)
        {

            var updatedStudent = await _mediator.Send(command);
            if (updatedStudent == null)
            {
                return NotFound("Student not found.");
            }
            return Ok(updatedStudent);
        }


        // Delete student by ID
        [HttpDelete("{Id}")]
        public async Task Delete(int Id)
        {
            await _mediator.Send(new DeleteStudentCommand { Id = Id });
        }


        [HttpPost("register")]
        public async Task<IActionResult> RegisterStudentToCourse([FromBody] RegisterStudentToCourseCommand command)
        {
            try
            {
                var student = await _mediator.Send(command);
                return Ok(student);
            }
            catch (Exception ex)
            {
                return BadRequest(ex.Message);
            }
        }


    }
}

