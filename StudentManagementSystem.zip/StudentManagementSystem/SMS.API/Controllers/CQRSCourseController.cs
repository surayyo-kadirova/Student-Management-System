﻿using System;
using MediatR;
using Microsoft.AspNetCore.Mvc;
using SMS.Business.CQRS.Commands;
using SMS.Business.CQRS.Queries;
using SMS.Entities;
using static Microsoft.EntityFrameworkCore.DbLoggerCategory.Database;

namespace SMS.API.Controllers
{
	[Route("api/[controller]")]
    [ApiController]
    public class CQRSCourseController: ControllerBase
    {
        private readonly IMediator _mediator;

        public CQRSCourseController(IMediator mediator)
        {
            _mediator = mediator;
        }

        [HttpGet]
        public async Task<IActionResult>GetAllCourses()
        {
            var course = await _mediator.Send(new GetAllCoursesQuery());
            return Ok(course);
        }

        [HttpGet("{Id}")]
        public async Task<IActionResult>GetCourseById(int Id)
        {
            try
            {
                var course = await _mediator.Send(new GetCourseByIdQuery { Id = Id });
          
                return Ok(course);
            }
            catch (KeyNotFoundException ex)
            {
                return NotFound(ex.Message);
            }
        }

        [HttpPost]
        public async Task<IActionResult>CreateCourse([FromBody] CreateCourseCommand command)
        {
            try
            {
                var course = await _mediator.Send(command);
                return CreatedAtAction(nameof(GetCourseById), new { Id = course.Id }, course);
            }
            catch (KeyNotFoundException ex)
            {
                return NotFound(ex.Message);
            }

        }

        [HttpPost("{update}")]
        public async Task<IActionResult> UpdateCourse([FromBody] UpdateCourseCommand command)
        {

            try
            {
                var updatedCourse = await _mediator.Send(command);
                return Ok(updatedCourse);
            }
            catch (KeyNotFoundException ex)
            {
                return NotFound(ex.Message);
            }
        }

        [HttpDelete("{Id}")]
        public async Task Delete(int Id)
        {
            await _mediator.Send(new DeleteCourseCommand { Id = Id });
        }

    }


}

