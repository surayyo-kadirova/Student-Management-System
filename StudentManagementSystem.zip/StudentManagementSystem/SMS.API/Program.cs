﻿// In Program.cs for .NET 6 and later
using SMS.Business.Abstract;
using SMS.Business.Concrete;
using SMS.DatabaseContext.Abstract;
using SMS.DatabaseContext.Concrete;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Hosting;
using MediatR;
using System.Reflection;
using System.Text.Json.Serialization;
using SMS.Business.CQRS.QueryHandlers;
using SMS.DatabaseContext;

var builder = WebApplication.CreateBuilder(args);

// Add services to the container
builder.Services.AddControllers();


// Dependency Injection için konteyner oluşturma
builder.Services.AddSingleton<ISMSService, SMSService>();
builder.Services.AddSingleton<ISMSRepository, SMSRepository>();

builder.Services.AddSingleton<ICourseService, CourseService>();
builder.Services.AddSingleton<ICourseRepository, CourseRepository>();



// Learn more about configuring Swagger/OpenAPI at 
builder.Services.AddEndpointsApiExplorer();
builder.Services.AddSwaggerGen();

//CQRS Pattern için MadiatR ayarlaması
builder.Services.AddMediatR(typeof(Program).Assembly);
builder.Services.AddMediatR(typeof(SMS.Business.CQRS.Commands.CreateStudentCommand).Assembly);

builder.Services.AddMediatR(typeof(GetAllStudentsQueryHandler).Assembly);
builder.Services.AddMediatR(typeof(GetAllCoursesQueryHandler).Assembly);
builder.Services.AddMediatR(typeof(GetAllStudentsWithCourseQueryHandler).Assembly);

var app = builder.Build();

// Configure the HTTP request pipeline.//SwagerUI
if (app.Environment.IsDevelopment())
{
    app.UseSwagger();
    app.UseSwaggerUI();
}
//Angular ayarlaması
app.UseHttpsRedirection();
app.UseCors(builder =>
    builder.AllowAnyOrigin()
           .AllowAnyMethod()
           .AllowAnyHeader());
app.UseAuthorization();
app.MapControllers();

app.Run();






